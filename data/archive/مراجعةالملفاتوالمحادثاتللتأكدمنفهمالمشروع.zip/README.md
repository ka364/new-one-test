# 🔧 HaderOS NOW SHOES - Order Management Pilot

**Version:** 0.1.0  
**Status:** 🟡 Active Development (Week 0)  
**Duration:** 8 Weeks  
**Ethical Rule:** "Don't sell what you don't have"

---

## 📋 Project Overview

This is a **Pilot MVP** for HaderOS integrated with NOW SHOES operations. The system manages order processing with a core ethical rule: prevent overselling by validating inventory before confirming orders.

### Core Objective
Prove the concept of an ethical, transparent order management system that:
- Receives orders from Shopify
- Validates against available inventory
- Confirms or rejects orders with full audit trail
- Maintains 100% transparency in decision-making

---

## 🏗️ Architecture

### Technology Stack
- **Backend:** Python 3.11 + FastAPI
- **Database:** PostgreSQL 15
- **Frontend:** React 18
- **Containerization:** Docker Compose
- **API:** RESTful with OpenAPI/Swagger docs

### Project Structure
```
haderos-nowshoes-pilot/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── config.py          # Configuration settings
│   │   ├── database.py        # Database connection
│   │   ├── models.py          # SQLAlchemy models
│   │   ├── schemas.py         # Pydantic schemas
│   │   ├── services.py        # Business logic
│   │   └── routes.py          # API endpoints
│   ├── main.py                # FastAPI application
│   ├── requirements.txt        # Python dependencies
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── index.js
│   │   ├── App.js
│   │   └── App.css
│   ├── public/
│   │   └── index.html
│   ├── package.json
│   └── Dockerfile
├── docs/                       # Documentation
├── tests/                      # Test files
├── docker-compose.yml          # Docker orchestration
├── .gitignore
└── README.md
```

---

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose installed
- Git

### Setup & Run

1. **Clone the repository**
```bash
cd haderos-nowshoes-pilot
```

2. **Start the services**
```bash
docker-compose up --build
```

3. **Access the application**
- **Frontend:** http://localhost:3000
- **API Docs:** http://localhost:8000/docs
- **API Health:** http://localhost:8000/api/v1/health

4. **Initialize sample data**
```bash
# Create sample inventory
curl -X POST http://localhost:8000/api/v1/inventory \
  -H "Content-Type: application/json" \
  -d '{"product_id": "SHOE-001", "quantity_available": 50}'

# Create an order
curl -X POST http://localhost:8000/api/v1/orders \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": "ORD-001",
    "customer_id": "CUST-001",
    "product_id": "SHOE-001",
    "quantity": 2
  }'

# Confirm order (applies ethical rule)
curl -X POST http://localhost:8000/api/v1/orders/ORD-001/confirm
```

---

## 📊 Database Schema

### Orders Table
```sql
CREATE TABLE orders (
  id INTEGER PRIMARY KEY,
  order_id VARCHAR(50) UNIQUE NOT NULL,
  customer_id VARCHAR(100) NOT NULL,
  product_id VARCHAR(100) NOT NULL,
  quantity INTEGER NOT NULL,
  status ENUM('received', 'validated', 'confirmed', 'rejected', 'fulfilled'),
  rejection_reason TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Inventory Table
```sql
CREATE TABLE inventory (
  id INTEGER PRIMARY KEY,
  product_id VARCHAR(100) UNIQUE NOT NULL,
  quantity_available INTEGER DEFAULT 0,
  quantity_reserved INTEGER DEFAULT 0,
  last_updated TIMESTAMP DEFAULT NOW()
);
```

### Audit Logs Table
```sql
CREATE TABLE audit_logs (
  id INTEGER PRIMARY KEY,
  action VARCHAR(100) NOT NULL,
  actor VARCHAR(100) NOT NULL,
  order_id VARCHAR(50),
  details TEXT,
  reason TEXT,
  timestamp TIMESTAMP DEFAULT NOW()
);
```

---

## 🔌 API Endpoints

### Orders
- `POST /api/v1/orders` - Create new order
- `GET /api/v1/orders` - List all orders
- `GET /api/v1/orders/{order_id}` - Get specific order
- `POST /api/v1/orders/{order_id}/validate` - Validate order against inventory
- `POST /api/v1/orders/{order_id}/confirm` - Confirm order (applies ethical rule)

### Inventory
- `POST /api/v1/inventory` - Create inventory entry
- `GET /api/v1/inventory/{product_id}` - Get inventory
- `PUT /api/v1/inventory/{product_id}` - Update inventory

### Audit Logs
- `GET /api/v1/audit-logs` - Get audit logs (optional filter by order_id)

### Health
- `GET /api/v1/health` - Health check

---

## ✅ Success Criteria (Week 8)

### Technical Success
- ✅ Response time < 3 seconds
- ✅ Error rate < 10%
- ✅ 95%+ unit test coverage
- ✅ API documentation complete

### Operational Success
- ✅ 5 complete orders processed end-to-end
- ✅ Team trained on system usage
- ✅ SOP documented (≤ 10 minutes)

### Ethical Success
- ✅ Ethical rule "Don't sell what you don't have" enforced 100%
- ✅ Every decision logged in audit trail
- ✅ Full transparency on rejections

---

## 📅 Timeline (8 Weeks)

| Week | Milestone | Status |
|------|-----------|--------|
| **0** | Setup, Docker, Initial DB | 🟢 In Progress |
| **1-2** | Core API, UI, Order Flow | ⚪ Planned |
| **3-4** | Ethical Rules, Audit Log, Testing | ⚪ Planned |
| **5-6** | Live Pilot (5-10 orders), Refinements | ⚪ Planned |
| **7-8** | Documentation, Training, Final Report | ⚪ Planned |

### Decision Points
- **Week 2:** Core functionality working?
- **Week 4:** Ethical rule enforced correctly?
- **Week 6:** Ready for live pilot?
- **Week 8:** Go/Pivot/Stop decision

---

## 🔐 Security & Compliance

### Data Protection
- All sensitive data encrypted at rest
- HTTPS enforced in production
- Database credentials managed via environment variables

### Audit Trail
- Every order action logged
- Actor (system/user) recorded
- Timestamp and reason documented
- No data deletion (soft deletes only)

### Ethical Enforcement
- Inventory validation before confirmation
- Overselling prevention (core rule)
- Decision transparency
- Immutable audit logs

---

## 🛠️ Development

### Run Tests
```bash
cd backend
pytest tests/
```

### Code Style
- Python: PEP 8 (Black formatter)
- JavaScript: ESLint + Prettier
- Commit messages: Conventional Commits

### Environment Variables
Create `.env` file:
```
DATABASE_URL=postgresql://haderos_user:haderos_password_dev@postgres:5432/haderos_nowshoes
ENVIRONMENT=development
DEBUG=true
```

---

## 📞 Support & Contact

**Project Owner:** Ahmed Shawky (Founder)  
**Technical Lead:** Mohammed Matta  
**Development:** Manus AI  

**Communication:**
- Weekly sync: Tuesday & Friday
- Incident response: WhatsApp group
- Documentation: This README + API Docs

---

## 📄 License

Proprietary - HaderOS Project  
All rights reserved © 2025

---

## 🎯 Next Steps

1. ✅ Week 0: Docker setup complete
2. ⏳ Week 1: API endpoints implementation
3. ⏳ Week 2: Frontend integration
4. ⏳ Week 3-4: Testing & refinement
5. ⏳ Week 5-6: Live pilot
6. ⏳ Week 7-8: Documentation & decision

---

**Last Updated:** December 17, 2025  
**Status:** 🟡 Active Development

from pydantic import BaseModel
from datetime import datetime
from typing import Optional
from app.models import OrderStatus

class OrderCreate(BaseModel):
    order_id: str
    customer_id: str
    product_id: str
    quantity: int

class OrderUpdate(BaseModel):
    status: OrderStatus
    rejection_reason: Optional[str] = None

class OrderResponse(BaseModel):
    id: int
    order_id: str
    customer_id: str
    product_id: str
    quantity: int
    status: OrderStatus
    rejection_reason: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class InventoryCreate(BaseModel):
    product_id: str
    quantity_available: int

class InventoryUpdate(BaseModel):
    quantity_available: int

class InventoryResponse(BaseModel):
    id: int
    product_id: str
    quantity_available: int
    quantity_reserved: int
    last_updated: datetime

    class Config:
        from_attributes = True

class AuditLogResponse(BaseModel):
    id: int
    action: str
    actor: str
    order_id: Optional[str]
    details: Optional[str]
    reason: Optional[str]
    timestamp: datetime

    class Config:
        from_attributes = True

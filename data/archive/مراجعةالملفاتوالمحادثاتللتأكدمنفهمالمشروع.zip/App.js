import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api/v1';

function App() {
  const [orders, setOrders] = useState([]);
  const [inventory, setInventory] = useState({});
  const [newOrder, setNewOrder] = useState({
    order_id: '',
    customer_id: '',
    product_id: '',
    quantity: ''
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  // Fetch orders on component mount
  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API_URL}/orders`);
      setOrders(response.data);
    } catch (error) {
      setMessage('Error fetching orders: ' + error.message);
    }
    setLoading(false);
  };

  const handleCreateOrder = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/orders`, newOrder);
      setOrders([...orders, response.data]);
      setNewOrder({
        order_id: '',
        customer_id: '',
        product_id: '',
        quantity: ''
      });
      setMessage('Order created successfully!');
      setTimeout(() => setMessage(''), 3000);
    } catch (error) {
      setMessage('Error creating order: ' + error.message);
    }
    setLoading(false);
  };

  const handleConfirmOrder = async (orderId) => {
    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/orders/${orderId}/confirm`);
      // Update the order in the list
      setOrders(orders.map(o => o.order_id === orderId ? response.data : o));
      setMessage('Order confirmed/rejected successfully!');
      setTimeout(() => setMessage(''), 3000);
    } catch (error) {
      setMessage('Error confirming order: ' + error.message);
    }
    setLoading(false);
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'confirmed': return '#4CAF50';
      case 'rejected': return '#f44336';
      case 'received': return '#2196F3';
      case 'validated': return '#FF9800';
      default: return '#999';
    }
  };

  return (
    <div className="app">
      <header className="header">
        <h1>🔧 HaderOS NOW SHOES - Order Management Pilot</h1>
        <p>Ethical Order Processing System</p>
      </header>

      <main className="container">
        {message && <div className="message">{message}</div>}

        {/* Create Order Form */}
        <section className="section">
          <h2>📝 Create New Order</h2>
          <form onSubmit={handleCreateOrder} className="form">
            <input
              type="text"
              placeholder="Order ID"
              value={newOrder.order_id}
              onChange={(e) => setNewOrder({...newOrder, order_id: e.target.value})}
              required
            />
            <input
              type="text"
              placeholder="Customer ID"
              value={newOrder.customer_id}
              onChange={(e) => setNewOrder({...newOrder, customer_id: e.target.value})}
              required
            />
            <input
              type="text"
              placeholder="Product ID"
              value={newOrder.product_id}
              onChange={(e) => setNewOrder({...newOrder, product_id: e.target.value})}
              required
            />
            <input
              type="number"
              placeholder="Quantity"
              value={newOrder.quantity}
              onChange={(e) => setNewOrder({...newOrder, quantity: parseInt(e.target.value)})}
              required
            />
            <button type="submit" disabled={loading}>Create Order</button>
          </form>
        </section>

        {/* Orders List */}
        <section className="section">
          <h2>📦 Orders ({orders.length})</h2>
          {loading ? (
            <p>Loading...</p>
          ) : orders.length === 0 ? (
            <p>No orders yet</p>
          ) : (
            <div className="orders-list">
              {orders.map((order) => (
                <div key={order.id} className="order-card">
                  <div className="order-header">
                    <h3>{order.order_id}</h3>
                    <span 
                      className="status-badge" 
                      style={{backgroundColor: getStatusColor(order.status)}}
                    >
                      {order.status}
                    </span>
                  </div>
                  <div className="order-details">
                    <p><strong>Customer:</strong> {order.customer_id}</p>
                    <p><strong>Product:</strong> {order.product_id}</p>
                    <p><strong>Quantity:</strong> {order.quantity}</p>
                    {order.rejection_reason && (
                      <p><strong>Reason:</strong> {order.rejection_reason}</p>
                    )}
                  </div>
                  {order.status === 'received' && (
                    <button 
                      className="btn-confirm"
                      onClick={() => handleConfirmOrder(order.order_id)}
                      disabled={loading}
                    >
                      Validate & Confirm
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      <footer className="footer">
        <p>HaderOS Pilot v0.1.0 | Ethical Rule: "Don't sell what you don't have"</p>
      </footer>
    </div>
  );
}

export default App;

/**
 * Quranic Verse with Translation Component
 * مكون عرض الآية القرآنية مع الترجمة المعتمدة من الأزهر
 * 
 * المبادئ:
 * 1. النص العربي دائماً مرئي وبارز
 * 2. الترجمة المعتمدة تحته (إن وجدت)
 * 3. بيانات الاعتماد من الأزهر واضحة
 */

import React, { useState, useEffect } from 'react';
import { translationEngine, type VerseWithTranslation } from '../engine/translation-engine';

// ===== Types =====

interface QuranicVerseWithTranslationProps {
  verseId: number;
  language?: string;
  translationId?: number;
  context?: string;
  showTranslationInfo?: boolean;
  onFeedback?: (rating: number, comment?: string) => void;
  className?: string;
}

// ===== Component =====

export const QuranicVerseWithTranslation: React.FC<QuranicVerseWithTranslationProps> = ({
  verseId,
  language = 'ar',
  translationId,
  context,
  showTranslationInfo = true,
  onFeedback,
  className = ''
}) => {
  const [verse, setVerse] = useState<VerseWithTranslation | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [startTime] = useState(Date.now());

  useEffect(() => {
    loadVerse();
  }, [verseId, language, translationId]);

  const loadVerse = async () => {
    try {
      setLoading(true);
      setError(null);

      const result = await translationEngine.getVerseWithTranslation(verseId, {
        language,
        translationId,
        showArabicText: true, // دائماً true
        showTranslation: language !== 'ar',
        showTransliteration: false
      });

      if (!result) {
        setError('الآية غير موجودة');
        return;
      }

      setVerse(result);
    } catch (err) {
      setError('حدث خطأ في تحميل الآية');
      console.error('Error loading verse:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFeedback = (rating: number, comment?: string) => {
    const viewDuration = Math.floor((Date.now() - startTime) / 1000);
    
    // تسجيل التغذية الراجعة
    if (onFeedback) {
      onFeedback(rating, comment);
    }
    
    // يمكن إضافة تسجيل إضافي هنا
  };

  if (loading) {
    return (
      <div className={`quranic-verse-loading ${className}`}>
        <div className="loading-spinner">جاري التحميل...</div>
      </div>
    );
  }

  if (error || !verse) {
    return (
      <div className={`quranic-verse-error ${className}`}>
        <p>{error || 'حدث خطأ'}</p>
      </div>
    );
  }

  return (
    <div className={`quranic-verse-container ${className}`} dir="rtl">
      {/* النص العربي الأصلي - دائماً مرئي وبارز */}
      <div className="arabic-text-section">
        <div className="verse-header">
          <span className="surah-name">{verse.surahName}</span>
          <span className="verse-separator">:</span>
          <span className="verse-number">{verse.verseNumber}</span>
        </div>
        
        <div className="arabic-text">
          {verse.unicodeText}
        </div>
        
        <div className="verse-key">
          {verse.verseKey}
        </div>
      </div>

      {/* الترجمة المعتمدة من الأزهر (إن وجدت) */}
      {verse.translation && (
        <div className="translation-section">
          <div className="translation-header">
            <span className="translation-label">الترجمة المعتمدة:</span>
          </div>
          
          <div className="translated-text" dir={language === 'ar' ? 'rtl' : 'ltr'}>
            {verse.translation.translatedText}
          </div>
          
          {showTranslationInfo && (
            <div className="translation-info">
              <div className="translation-details">
                <span className="translation-name">
                  {verse.translation.translationName}
                </span>
                <span className="translator-name">
                  - {verse.translation.translatorName}
                </span>
              </div>
              
              <div className="azhar-approval">
                <span className="approval-badge">
                  ✓ معتمد من الأزهر الشريف
                </span>
                <span className="approval-number">
                  رقم الاعتماد: {verse.translation.azharApprovalNumber}
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* التوجيه الأخلاقي (مترجم بحرية) */}
      <div className="ethical-principle-section">
        <div className="ethical-header">
          <span className="ethical-label">التوجيه الأخلاقي:</span>
        </div>
        
        <div className="ethical-text">
          {verse.ethicalPrinciple.translated || verse.ethicalPrinciple.ar}
        </div>
      </div>

      {/* التطبيقات الإدارية (مترجمة بحرية) */}
      {context && verse.managementApplications && (
        <div className="management-applications-section">
          <div className="applications-header">
            <span className="applications-label">التطبيق العملي:</span>
          </div>
          
          <div className="applications-list">
            {Object.entries(
              verse.managementApplications.translated || verse.managementApplications.ar
            ).map(([key, value]) => (
              key === context && (
                <div key={key} className="application-item">
                  <span className="application-icon">💡</span>
                  <span className="application-text">{value}</span>
                </div>
              )
            ))}
          </div>
        </div>
      )}

      {/* التغذية الراجعة */}
      {onFeedback && (
        <div className="feedback-section">
          <div className="feedback-header">
            <span className="feedback-label">هل كان هذا التوجيه مفيداً؟</span>
          </div>
          
          <div className="feedback-buttons">
            {[1, 2, 3, 4, 5].map((rating) => (
              <button
                key={rating}
                className="feedback-button"
                onClick={() => handleFeedback(rating)}
                title={`${rating} من 5`}
              >
                ⭐
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// ===== Language Selector Component =====

interface LanguageSelectorProps {
  currentLanguage: string;
  onLanguageChange: (language: string) => void;
  className?: string;
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  currentLanguage,
  onLanguageChange,
  className = ''
}) => {
  const [languages, setLanguages] = useState<Array<{
    code: string;
    nameAr: string;
    nativeName: string;
  }>>([]);

  useEffect(() => {
    loadLanguages();
  }, []);

  const loadLanguages = async () => {
    try {
      const supportedLanguages = await translationEngine.getSupportedLanguages();
      setLanguages(supportedLanguages.map(lang => ({
        code: lang.code,
        nameAr: lang.nameAr,
        nativeName: lang.nativeName
      })));
    } catch (err) {
      console.error('Error loading languages:', err);
    }
  };

  return (
    <div className={`language-selector ${className}`}>
      <label htmlFor="language-select" className="language-label">
        اللغة:
      </label>
      
      <select
        id="language-select"
        value={currentLanguage}
        onChange={(e) => onLanguageChange(e.target.value)}
        className="language-select"
      >
        <option value="ar">العربية (الأصل)</option>
        {languages.map((lang) => (
          <option key={lang.code} value={lang.code}>
            {lang.nameAr} ({lang.nativeName})
          </option>
        ))}
      </select>
    </div>
  );
};

// ===== Translation Selector Component =====

interface TranslationSelectorProps {
  language: string;
  currentTranslationId?: number;
  onTranslationChange: (translationId: number) => void;
  className?: string;
}

export const TranslationSelector: React.FC<TranslationSelectorProps> = ({
  language,
  currentTranslationId,
  onTranslationChange,
  className = ''
}) => {
  const [translations, setTranslations] = useState<Array<{
    id: number;
    translationName: string;
    translatorName: string;
    azharApprovalNumber: string;
    isDefault: boolean;
  }>>([]);

  useEffect(() => {
    if (language !== 'ar') {
      loadTranslations();
    }
  }, [language]);

  const loadTranslations = async () => {
    try {
      const availableTranslations = await translationEngine.getAvailableTranslations(language);
      setTranslations(availableTranslations.map(trans => ({
        id: trans.id,
        translationName: trans.translationName,
        translatorName: trans.translatorName,
        azharApprovalNumber: trans.azharApprovalNumber,
        isDefault: trans.isDefault
      })));
    } catch (err) {
      console.error('Error loading translations:', err);
    }
  };

  if (language === 'ar' || translations.length === 0) {
    return null;
  }

  return (
    <div className={`translation-selector ${className}`}>
      <label htmlFor="translation-select" className="translation-label">
        الترجمة المعتمدة:
      </label>
      
      <select
        id="translation-select"
        value={currentTranslationId || ''}
        onChange={(e) => onTranslationChange(Number(e.target.value))}
        className="translation-select"
      >
        {translations.map((trans) => (
          <option key={trans.id} value={trans.id}>
            {trans.translationName} - {trans.translatorName}
            {trans.isDefault && ' (الافتراضية)'}
          </option>
        ))}
      </select>
      
      <div className="translation-note">
        <span className="note-icon">ℹ️</span>
        <span className="note-text">
          جميع الترجمات معتمدة من الأزهر الشريف
        </span>
      </div>
    </div>
  );
};

// ===== Styles =====

export const quranicVerseStyles = `
.quranic-verse-container {
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  border-radius: 12px;
  padding: 24px;
  margin: 16px 0;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  font-family: 'Traditional Arabic', 'Amiri', serif;
}

/* النص العربي الأصلي */
.arabic-text-section {
  background: white;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 16px;
  border-right: 4px solid #2c5282;
}

.verse-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 16px;
  color: #2c5282;
  font-size: 16px;
  font-weight: 600;
}

.arabic-text {
  font-size: 24px;
  line-height: 2;
  color: #1a202c;
  text-align: justify;
  margin-bottom: 12px;
  font-weight: 500;
}

.verse-key {
  text-align: left;
  color: #718096;
  font-size: 14px;
}

/* الترجمة المعتمدة */
.translation-section {
  background: #f7fafc;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
  border-right: 4px solid #48bb78;
}

.translation-header {
  margin-bottom: 12px;
  color: #2d3748;
  font-weight: 600;
}

.translated-text {
  font-size: 18px;
  line-height: 1.8;
  color: #2d3748;
  margin-bottom: 12px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.translation-info {
  border-top: 1px solid #e2e8f0;
  padding-top: 12px;
  margin-top: 12px;
}

.translation-details {
  display: flex;
  gap: 8px;
  margin-bottom: 8px;
  font-size: 14px;
  color: #4a5568;
}

.azhar-approval {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 13px;
}

.approval-badge {
  background: #48bb78;
  color: white;
  padding: 4px 12px;
  border-radius: 12px;
  font-weight: 600;
}

.approval-number {
  color: #718096;
  font-family: monospace;
}

/* التوجيه الأخلاقي */
.ethical-principle-section {
  background: #fffaf0;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
  border-right: 4px solid #ed8936;
}

.ethical-header {
  margin-bottom: 12px;
  color: #c05621;
  font-weight: 600;
}

.ethical-text {
  font-size: 16px;
  line-height: 1.8;
  color: #2d3748;
}

/* التطبيقات الإدارية */
.management-applications-section {
  background: #f0fff4;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
  border-right: 4px solid #38b2ac;
}

.applications-header {
  margin-bottom: 12px;
  color: #2c7a7b;
  font-weight: 600;
}

.applications-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.application-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  font-size: 15px;
  line-height: 1.6;
  color: #2d3748;
}

.application-icon {
  font-size: 20px;
  flex-shrink: 0;
}

/* التغذية الراجعة */
.feedback-section {
  background: white;
  border-radius: 8px;
  padding: 16px;
  text-align: center;
}

.feedback-header {
  margin-bottom: 12px;
  color: #4a5568;
  font-weight: 600;
}

.feedback-buttons {
  display: flex;
  justify-content: center;
  gap: 8px;
}

.feedback-button {
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  transition: transform 0.2s;
  padding: 4px;
}

.feedback-button:hover {
  transform: scale(1.2);
}

/* Language & Translation Selectors */
.language-selector,
.translation-selector {
  margin-bottom: 16px;
}

.language-label,
.translation-label {
  display: block;
  margin-bottom: 8px;
  color: #2d3748;
  font-weight: 600;
}

.language-select,
.translation-select {
  width: 100%;
  padding: 10px;
  border: 2px solid #e2e8f0;
  border-radius: 6px;
  font-size: 15px;
  background: white;
  cursor: pointer;
}

.language-select:focus,
.translation-select:focus {
  outline: none;
  border-color: #4299e1;
}

.translation-note {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 8px;
  padding: 8px;
  background: #e6fffa;
  border-radius: 4px;
  font-size: 13px;
  color: #2c7a7b;
}

/* Loading & Error States */
.quranic-verse-loading,
.quranic-verse-error {
  padding: 40px;
  text-align: center;
  background: #f7fafc;
  border-radius: 8px;
}

.loading-spinner {
  color: #4299e1;
  font-size: 16px;
}

/* Responsive */
@media (max-width: 768px) {
  .quranic-verse-container {
    padding: 16px;
  }
  
  .arabic-text {
    font-size: 20px;
  }
  
  .translated-text {
    font-size: 16px;
  }
}
`;

// ===== Export =====

export default QuranicVerseWithTranslation;

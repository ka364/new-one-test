/**
 * KAIA Translation Engine
 * محرك الترجمات المعتمدة من الأزهر
 * 
 * المبادئ الأساسية:
 * 1. النص العربي الأصلي لا يُترجم أبداً ويُعرض دائماً
 * 2. الترجمات المعتمدة من الأزهر فقط
 * 3. التوجيه الأخلاقي والتطبيق العملي قابل للترجمة بحرية
 */

import { db } from '../db';
import { 
  azharApprovedTranslations,
  verseTranslations,
  ethicalPrincipleTranslations,
  supportedLanguages,
  userTranslationPreferences,
  translationUsageLog,
  type AzharApprovedTranslation,
  type VerseTranslation,
  type EthicalPrincipleTranslation
} from '../database/schema-kaia-translations';
import { quranicVerses, type QuranicVerse } from '../database/schema-kaia';
import { eq, and } from 'drizzle-orm';

// ===== Types =====

export interface VerseWithTranslation {
  // النص العربي الأصلي (دائماً موجود)
  arabicText: string;
  unicodeText: string;
  verseKey: string;
  surahName: string;
  verseNumber: number;
  
  // الترجمة المعتمدة (إن وجدت)
  translation?: {
    translatedText: string;
    translationName: string;
    translatorName: string;
    azharApprovalNumber: string;
    language: string;
  };
  
  // التوجيه الأخلاقي (مترجم بحرية)
  ethicalPrinciple: {
    ar: string;
    translated?: string;
  };
  
  // التطبيقات الإدارية (مترجمة بحرية)
  managementApplications: {
    ar: Record<string, string>;
    translated?: Record<string, string>;
  };
}

export interface TranslationDisplayOptions {
  userId?: number;
  language: string;
  translationId?: number; // ترجمة محددة، أو الافتراضية
  showArabicText: boolean; // دائماً true
  showTranslation: boolean;
  showTransliteration: boolean;
}

// ===== Translation Engine Class =====

export class KAIATranslationEngine {
  /**
   * الحصول على آية مع ترجمتها المعتمدة
   */
  async getVerseWithTranslation(
    verseId: number,
    options: TranslationDisplayOptions
  ): Promise<VerseWithTranslation | null> {
    // 1. الحصول على الآية الأصلية (العربية)
    const verse = await db.query.quranicVerses.findFirst({
      where: eq(quranicVerses.id, verseId)
    });
    
    if (!verse) {
      return null;
    }
    
    // 2. بناء الكائن الأساسي (النص العربي دائماً موجود)
    const result: VerseWithTranslation = {
      arabicText: verse.arabicText,
      unicodeText: verse.unicodeText,
      verseKey: verse.verseKey,
      surahName: verse.surahName,
      verseNumber: verse.verseNumber,
      ethicalPrinciple: {
        ar: verse.ethicalPrincipleAr
      },
      managementApplications: {
        ar: verse.managementApplications as Record<string, string>
      }
    };
    
    // 3. إضافة الترجمة المعتمدة (إن طُلبت)
    if (options.showTranslation && options.language !== 'ar') {
      const translation = await this.getApprovedTranslation(
        verseId,
        options.language,
        options.translationId
      );
      
      if (translation) {
        result.translation = translation;
      }
    }
    
    // 4. إضافة ترجمة التوجيه الأخلاقي (ليس القرآن)
    if (options.language !== 'ar') {
      const ethicalTranslation = await this.getEthicalPrincipleTranslation(
        verseId,
        options.language
      );
      
      if (ethicalTranslation) {
        result.ethicalPrinciple.translated = ethicalTranslation.ethicalPrinciple;
        result.managementApplications.translated = ethicalTranslation.managementApplications as Record<string, string>;
      }
    }
    
    // 5. تسجيل الاستخدام
    if (result.translation) {
      await this.logTranslationUsage({
        userId: options.userId,
        verseId,
        translationId: result.translation.azharApprovalNumber,
        language: options.language
      });
    }
    
    return result;
  }
  
  /**
   * الحصول على الترجمة المعتمدة من الأزهر
   */
  private async getApprovedTranslation(
    verseId: number,
    language: string,
    translationId?: number
  ): Promise<{
    translatedText: string;
    translationName: string;
    translatorName: string;
    azharApprovalNumber: string;
    language: string;
  } | null> {
    let translation: AzharApprovedTranslation | undefined;
    
    // إذا حُدد translationId، استخدمه
    if (translationId) {
      translation = await db.query.azharApprovedTranslations.findFirst({
        where: and(
          eq(azharApprovedTranslations.id, translationId),
          eq(azharApprovedTranslations.language, language),
          eq(azharApprovedTranslations.isActive, true)
        )
      });
    } else {
      // وإلا، استخدم الترجمة الافتراضية لهذه اللغة
      translation = await db.query.azharApprovedTranslations.findFirst({
        where: and(
          eq(azharApprovedTranslations.language, language),
          eq(azharApprovedTranslations.isDefault, true),
          eq(azharApprovedTranslations.isActive, true)
        )
      });
    }
    
    if (!translation) {
      return null;
    }
    
    // الحصول على النص المترجم
    const verseTranslation = await db.query.verseTranslations.findFirst({
      where: and(
        eq(verseTranslations.verseId, verseId),
        eq(verseTranslations.translationId, translation.id),
        eq(verseTranslations.isVerified, true)
      )
    });
    
    if (!verseTranslation) {
      return null;
    }
    
    return {
      translatedText: verseTranslation.translatedText,
      translationName: translation.translationName,
      translatorName: translation.translatorName,
      azharApprovalNumber: translation.azharApprovalNumber,
      language: translation.language
    };
  }
  
  /**
   * الحصول على ترجمة التوجيه الأخلاقي (ليس القرآن)
   */
  private async getEthicalPrincipleTranslation(
    verseId: number,
    language: string
  ): Promise<EthicalPrincipleTranslation | null> {
    const translation = await db.query.ethicalPrincipleTranslations.findFirst({
      where: and(
        eq(ethicalPrincipleTranslations.verseId, verseId),
        eq(ethicalPrincipleTranslations.language, language)
      )
    });
    
    return translation || null;
  }
  
  /**
   * الحصول على جميع الترجمات المعتمدة المتاحة للغة معينة
   */
  async getAvailableTranslations(language: string): Promise<AzharApprovedTranslation[]> {
    const translations = await db.query.azharApprovedTranslations.findMany({
      where: and(
        eq(azharApprovedTranslations.language, language),
        eq(azharApprovedTranslations.isActive, true)
      ),
      orderBy: (translations, { desc }) => [desc(translations.isDefault)]
    });
    
    return translations;
  }
  
  /**
   * الحصول على اللغات المدعومة
   */
  async getSupportedLanguages(): Promise<typeof supportedLanguages.$inferSelect[]> {
    const languages = await db.query.supportedLanguages.findMany({
      where: eq(supportedLanguages.isActive, true),
      orderBy: (languages, { desc }) => [desc(languages.totalUsers)]
    });
    
    return languages;
  }
  
  /**
   * الحصول على تفضيلات المستخدم للترجمة
   */
  async getUserPreferences(userId: number): Promise<typeof userTranslationPreferences.$inferSelect | null> {
    const preferences = await db.query.userTranslationPreferences.findFirst({
      where: eq(userTranslationPreferences.userId, userId)
    });
    
    return preferences || null;
  }
  
  /**
   * حفظ تفضيلات المستخدم للترجمة
   */
  async saveUserPreferences(
    userId: number,
    preferences: {
      preferredLanguage: string;
      preferredTranslationId?: number;
      showTranslation?: boolean;
      showTransliteration?: boolean;
      arabicFontSize?: number;
      translationFontSize?: number;
    }
  ): Promise<void> {
    const existing = await this.getUserPreferences(userId);
    
    if (existing) {
      // تحديث
      await db.update(userTranslationPreferences)
        .set({
          ...preferences,
          showArabicText: true, // دائماً true
          updatedAt: new Date()
        })
        .where(eq(userTranslationPreferences.userId, userId));
    } else {
      // إنشاء جديد
      await db.insert(userTranslationPreferences).values({
        userId,
        ...preferences,
        showArabicText: true, // دائماً true
        showTranslation: preferences.showTranslation ?? true,
        showTransliteration: preferences.showTransliteration ?? false
      });
    }
  }
  
  /**
   * تسجيل استخدام ترجمة
   */
  private async logTranslationUsage(params: {
    userId?: number;
    verseId: number;
    translationId: string;
    language: string;
    context?: string;
    viewDuration?: number;
  }): Promise<void> {
    // الحصول على ID الترجمة من رقم الاعتماد
    const translation = await db.query.azharApprovedTranslations.findFirst({
      where: eq(azharApprovedTranslations.azharApprovalNumber, params.translationId)
    });
    
    if (!translation) {
      return;
    }
    
    await db.insert(translationUsageLog).values({
      userId: params.userId,
      verseId: params.verseId,
      translationId: translation.id,
      language: params.language,
      context: params.context,
      viewDuration: params.viewDuration
    });
    
    // تحديث إحصائيات الترجمة
    await db.update(azharApprovedTranslations)
      .set({
        timesUsed: translation.timesUsed + 1
      })
      .where(eq(azharApprovedTranslations.id, translation.id));
  }
  
  /**
   * التحقق من صحة الترجمة (هل معتمدة من الأزهر؟)
   */
  async verifyTranslation(azharApprovalNumber: string): Promise<{
    isValid: boolean;
    translation?: AzharApprovedTranslation;
    message: string;
  }> {
    const translation = await db.query.azharApprovedTranslations.findFirst({
      where: eq(azharApprovedTranslations.azharApprovalNumber, azharApprovalNumber)
    });
    
    if (!translation) {
      return {
        isValid: false,
        message: 'رقم الاعتماد غير موجود'
      };
    }
    
    if (!translation.isActive) {
      return {
        isValid: false,
        translation,
        message: 'الترجمة غير نشطة'
      };
    }
    
    return {
      isValid: true,
      translation,
      message: 'ترجمة معتمدة من الأزهر الشريف'
    };
  }
  
  /**
   * البحث عن آيات مع الترجمة
   */
  async searchVersesWithTranslation(
    query: string,
    language: string,
    searchInTranslation: boolean = true
  ): Promise<VerseWithTranslation[]> {
    // البحث في النص العربي دائماً
    const verses = await db.query.quranicVerses.findMany({
      where: (verses, { or, like }) => or(
        like(verses.arabicText, `%${query}%`),
        like(verses.keywords, `%${query}%`)
      ),
      limit: 20
    });
    
    // إضافة الترجمات
    const results: VerseWithTranslation[] = [];
    
    for (const verse of verses) {
      const verseWithTranslation = await this.getVerseWithTranslation(
        verse.id,
        {
          language,
          showArabicText: true,
          showTranslation: true,
          showTransliteration: false
        }
      );
      
      if (verseWithTranslation) {
        results.push(verseWithTranslation);
      }
    }
    
    // إذا طُلب البحث في الترجمة أيضاً
    if (searchInTranslation && language !== 'ar') {
      // TODO: البحث في نصوص الترجمات
    }
    
    return results;
  }
  
  /**
   * الحصول على إحصائيات الترجمات
   */
  async getTranslationStatistics(language?: string): Promise<{
    totalTranslations: number;
    totalLanguages: number;
    totalVerses: number;
    translatedVerses: number;
    completionPercentage: number;
    topTranslations: Array<{
      translationName: string;
      timesUsed: number;
      averageRating: number;
    }>;
  }> {
    // TODO: تنفيذ الإحصائيات
    return {
      totalTranslations: 0,
      totalLanguages: 0,
      totalVerses: 6236,
      translatedVerses: 0,
      completionPercentage: 0,
      topTranslations: []
    };
  }
}

// ===== Singleton Instance =====

export const translationEngine = new KAIATranslationEngine();

// ===== Helper Functions =====

/**
 * تنسيق عرض الآية مع الترجمة
 */
export function formatVerseDisplay(verse: VerseWithTranslation): {
  arabic: string;
  translation?: string;
  reference: string;
  ethicalPrinciple: string;
  applications: string[];
} {
  return {
    arabic: verse.unicodeText,
    translation: verse.translation?.translatedText,
    reference: `${verse.surahName} : ${verse.verseNumber}`,
    ethicalPrinciple: verse.ethicalPrinciple.translated || verse.ethicalPrinciple.ar,
    applications: Object.values(
      verse.managementApplications.translated || verse.managementApplications.ar
    )
  };
}

/**
 * التحقق من توفر ترجمة للغة معينة
 */
export async function isLanguageSupported(language: string): Promise<boolean> {
  const lang = await db.query.supportedLanguages.findFirst({
    where: and(
      eq(supportedLanguages.code, language),
      eq(supportedLanguages.isActive, true)
    )
  });
  
  return !!lang;
}

/**
 * الحصول على الترجمة الافتراضية للغة
 */
export async function getDefaultTranslation(language: string): Promise<AzharApprovedTranslation | null> {
  const translation = await db.query.azharApprovedTranslations.findFirst({
    where: and(
      eq(azharApprovedTranslations.language, language),
      eq(azharApprovedTranslations.isDefault, true),
      eq(azharApprovedTranslations.isActive, true)
    )
  });
  
  return translation || null;
}

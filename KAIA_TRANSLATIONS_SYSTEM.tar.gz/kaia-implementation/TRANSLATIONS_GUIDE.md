# 🌍 دليل نظام الترجمات المعتمدة من الأزهر

## نظرة عامة

نظام الترجمات في KAIA يوفر دعماً متعدد اللغات للمستخدمين غير الناطقين بالعربية، مع الالتزام الكامل بالمبادئ التالية:

### **المبادئ الأساسية:**

1. ✅ **النص العربي الأصلي لا يُترجم أبداً** - يُعرض دائماً وبشكل بارز
2. ✅ **الترجمات المعتمدة من الأزهر فقط** - لا ترجمات غير معتمدة
3. ✅ **التوجيه الأخلاقي والتطبيق العملي قابل للترجمة** - هذا ليس قرآن
4. ✅ **الشفافية الكاملة** - بيانات الاعتماد واضحة للمستخدم

---

## 📊 البنية المعمارية

### **الطبقات:**

```
┌─────────────────────────────────────────┐
│         واجهة المستخدم (UI)             │
│  QuranicVerseWithTranslation Component  │
└─────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│       محرك الترجمات (Engine)            │
│     KAIATranslationEngine Class         │
└─────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│       قاعدة البيانات (Database)         │
│  7 جداول للترجمات المعتمدة             │
└─────────────────────────────────────────┘
```

---

## 🗄️ قاعدة البيانات

### **الجداول الرئيسية:**

#### **1. azhar_approved_translations**
يحتوي على معلومات الترجمات المعتمدة من الأزهر

```sql
CREATE TABLE azhar_approved_translations (
  id SERIAL PRIMARY KEY,
  translation_name VARCHAR(200) NOT NULL,
  translation_name_ar VARCHAR(200) NOT NULL,
  language VARCHAR(10) NOT NULL,
  language_name_ar VARCHAR(50) NOT NULL,
  translator_name VARCHAR(200) NOT NULL,
  translator_name_ar VARCHAR(200) NOT NULL,
  
  -- الاعتماد من الأزهر
  azhar_approval_number VARCHAR(100) NOT NULL UNIQUE,
  azhar_approval_date TIMESTAMP NOT NULL,
  azhar_approval_document TEXT,
  approved_by VARCHAR(200) NOT NULL,
  approved_by_title VARCHAR(200),
  
  -- الحالة
  is_active BOOLEAN DEFAULT TRUE,
  is_default BOOLEAN DEFAULT FALSE,
  
  -- الإحصائيات
  times_used INTEGER DEFAULT 0,
  average_rating INTEGER,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

**الحقول المهمة:**
- `azhar_approval_number`: رقم الاعتماد الفريد من الأزهر
- `is_default`: الترجمة الافتراضية لهذه اللغة
- `approved_by`: اسم المعتمد من الأزهر الشريف

---

#### **2. verse_translations**
يربط كل آية بترجماتها المعتمدة

```sql
CREATE TABLE verse_translations (
  id SERIAL PRIMARY KEY,
  verse_id INTEGER REFERENCES quranic_verses(id) NOT NULL,
  translation_id INTEGER REFERENCES azhar_approved_translations(id) NOT NULL,
  translated_text TEXT NOT NULL,
  translation_notes TEXT,
  is_verified BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

#### **3. ethical_principle_translations**
ترجمة التوجيه الأخلاقي (ليس القرآن)

```sql
CREATE TABLE ethical_principle_translations (
  id SERIAL PRIMARY KEY,
  verse_id INTEGER REFERENCES quranic_verses(id) NOT NULL,
  language VARCHAR(10) NOT NULL,
  ethical_principle TEXT NOT NULL,
  management_applications JSONB DEFAULT '{}',
  keywords JSONB DEFAULT '[]',
  created_at TIMESTAMP DEFAULT NOW()
);
```

**ملاحظة مهمة:**  
هذا الجدول يحتوي على ترجمات **التوجيه الأخلاقي والتطبيق العملي**، وليس القرآن نفسه.

---

#### **4. supported_languages**
قائمة اللغات المدعومة

```sql
CREATE TABLE supported_languages (
  id SERIAL PRIMARY KEY,
  code VARCHAR(10) NOT NULL UNIQUE,
  name_en VARCHAR(100) NOT NULL,
  name_ar VARCHAR(100) NOT NULL,
  native_name VARCHAR(100) NOT NULL,
  direction VARCHAR(3) DEFAULT 'ltr',
  default_translation_id INTEGER REFERENCES azhar_approved_translations(id),
  is_active BOOLEAN DEFAULT TRUE,
  is_complete BOOLEAN DEFAULT FALSE,
  completion_percentage INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

#### **5. user_translation_preferences**
تفضيلات المستخدم للترجمة

```sql
CREATE TABLE user_translation_preferences (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  preferred_language VARCHAR(10) NOT NULL,
  preferred_translation_id INTEGER REFERENCES azhar_approved_translations(id),
  show_arabic_text BOOLEAN DEFAULT TRUE, -- دائماً TRUE
  show_translation BOOLEAN DEFAULT TRUE,
  arabic_font_size INTEGER DEFAULT 18,
  translation_font_size INTEGER DEFAULT 14,
  created_at TIMESTAMP DEFAULT NOW()
);
```

**ملاحظة:**  
`show_arabic_text` دائماً `TRUE` ولا يمكن تغييره.

---

#### **6. translation_usage_log**
سجل استخدام الترجمات

```sql
CREATE TABLE translation_usage_log (
  id SERIAL PRIMARY KEY,
  user_id INTEGER,
  verse_id INTEGER REFERENCES quranic_verses(id),
  translation_id INTEGER REFERENCES azhar_approved_translations(id),
  language VARCHAR(10) NOT NULL,
  context VARCHAR(50),
  view_duration INTEGER,
  was_helpful BOOLEAN,
  feedback TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

#### **7. translation_requests**
طلبات ترجمات جديدة من المستخدمين

```sql
CREATE TABLE translation_requests (
  id SERIAL PRIMARY KEY,
  requested_language VARCHAR(10) NOT NULL,
  requested_language_name VARCHAR(100) NOT NULL,
  requested_by INTEGER,
  reason TEXT,
  estimated_users INTEGER,
  priority INTEGER DEFAULT 5,
  votes INTEGER DEFAULT 0,
  status VARCHAR(20) DEFAULT 'pending',
  translation_progress INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

## ⚙️ المحرك (Engine)

### **KAIATranslationEngine Class**

#### **الوظائف الرئيسية:**

##### **1. getVerseWithTranslation()**
الحصول على آية مع ترجمتها المعتمدة

```typescript
const verse = await translationEngine.getVerseWithTranslation(verseId, {
  language: 'en',
  translationId: 1, // اختياري
  showArabicText: true, // دائماً true
  showTranslation: true,
  showTransliteration: false
});

// النتيجة:
{
  // النص العربي الأصلي (دائماً موجود)
  arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
  unicodeText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
  verseKey: "1:1",
  surahName: "الفاتحة",
  verseNumber: 1,
  
  // الترجمة المعتمدة (إن وجدت)
  translation: {
    translatedText: "In the name of Allah, the Entirely Merciful...",
    translationName: "Sahih International",
    translatorName: "Saheeh International",
    azharApprovalNumber: "AZHAR-EN-001-2020",
    language: "en"
  },
  
  // التوجيه الأخلاقي (مترجم بحرية)
  ethicalPrinciple: {
    ar: "البدء بذكر الله",
    translated: "Beginning with the name of Allah"
  }
}
```

---

##### **2. getAvailableTranslations()**
الحصول على جميع الترجمات المعتمدة للغة

```typescript
const translations = await translationEngine.getAvailableTranslations('en');

// النتيجة:
[
  {
    id: 1,
    translationName: "Sahih International",
    translatorName: "Saheeh International",
    azharApprovalNumber: "AZHAR-EN-001-2020",
    isDefault: true
  },
  {
    id: 2,
    translationName: "Pickthall",
    translatorName: "Mohammed Marmaduke Pickthall",
    azharApprovalNumber: "AZHAR-EN-002-2019",
    isDefault: false
  }
]
```

---

##### **3. getSupportedLanguages()**
الحصول على اللغات المدعومة

```typescript
const languages = await translationEngine.getSupportedLanguages();

// النتيجة:
[
  {
    code: 'en',
    nameAr: 'الإنجليزية',
    nativeName: 'English',
    isComplete: true,
    completionPercentage: 100
  },
  {
    code: 'fr',
    nameAr: 'الفرنسية',
    nativeName: 'Français',
    isComplete: false,
    completionPercentage: 85
  }
]
```

---

##### **4. verifyTranslation()**
التحقق من صحة الترجمة (هل معتمدة من الأزهر؟)

```typescript
const verification = await translationEngine.verifyTranslation('AZHAR-EN-001-2020');

// النتيجة:
{
  isValid: true,
  translation: { /* بيانات الترجمة */ },
  message: "ترجمة معتمدة من الأزهر الشريف"
}
```

---

## 🎨 واجهة المستخدم (UI)

### **QuranicVerseWithTranslation Component**

#### **الاستخدام الأساسي:**

```tsx
import { QuranicVerseWithTranslation } from '@/components/QuranicVerseWithTranslation';

<QuranicVerseWithTranslation
  verseId={1}
  language="en"
  translationId={1}
  context="employee_evaluation"
  showTranslationInfo={true}
  onFeedback={(rating, comment) => {
    console.log('Rating:', rating);
  }}
/>
```

---

#### **الخصائص (Props):**

| الخاصية | النوع | الوصف | الافتراضي |
|---------|------|-------|----------|
| `verseId` | `number` | معرّف الآية | **مطلوب** |
| `language` | `string` | كود اللغة (en, fr, etc.) | `'ar'` |
| `translationId` | `number` | معرّف ترجمة محددة | `undefined` |
| `context` | `string` | السياق (employee_evaluation, etc.) | `undefined` |
| `showTranslationInfo` | `boolean` | عرض معلومات الترجمة | `true` |
| `onFeedback` | `function` | دالة التغذية الراجعة | `undefined` |

---

#### **المكونات المساعدة:**

##### **LanguageSelector**
اختيار اللغة

```tsx
import { LanguageSelector } from '@/components/QuranicVerseWithTranslation';

<LanguageSelector
  currentLanguage="en"
  onLanguageChange={(lang) => setLanguage(lang)}
/>
```

---

##### **TranslationSelector**
اختيار الترجمة المعتمدة

```tsx
import { TranslationSelector } from '@/components/QuranicVerseWithTranslation';

<TranslationSelector
  language="en"
  currentTranslationId={1}
  onTranslationChange={(id) => setTranslationId(id)}
/>
```

---

## 📥 استيراد الترجمات

### **تنسيق ملف الترجمة:**

```json
{
  "metadata": {
    "translationName": "Sahih International",
    "translationNameAr": "الترجمة الدولية الصحيحة",
    "language": "en",
    "languageNameAr": "الإنجليزية",
    "translatorName": "Saheeh International",
    "translatorNameAr": "الترجمة الدولية الصحيحة",
    "azharApprovalNumber": "AZHAR-EN-001-2020",
    "azharApprovalDate": "2020-01-15",
    "azharApprovalDocument": "https://azhar.eg/approvals/AZHAR-EN-001-2020.pdf",
    "approvedBy": "لجنة الترجمة بالأزهر الشريف",
    "approvedByTitle": "رئيس لجنة الترجمة",
    "publisher": "Dar Al-Azhar",
    "publishYear": 2020,
    "isbn": "978-1-234567-89-0",
    "isDefault": true
  },
  "verses": [
    {
      "verseKey": "1:1",
      "translatedText": "In the name of Allah, the Entirely Merciful, the Especially Merciful.",
      "translationNotes": "Optional notes about this specific verse"
    },
    {
      "verseKey": "1:2",
      "translatedText": "[All] praise is [due] to Allah, Lord of the worlds -"
    }
  ]
}
```

---

### **خطوات الاستيراد:**

#### **1. تحضير ملف الترجمة**

```bash
# إنشاء مجلد الترجمات
mkdir -p server/kaia/data/azhar-translations

# نسخ ملف الترجمة
cp sahih-international.json server/kaia/data/azhar-translations/
```

---

#### **2. تشغيل Script الاستيراد**

```bash
pnpm tsx scripts/import-azhar-translations.ts
```

**النتيجة:**
```
🕌 بدء استيراد الترجمات المعتمدة من الأزهر الشريف...

📁 تم العثور على 1 ملف ترجمة

📖 استيراد: sahih-international.json...
   ✅ تمت إضافة اللغة: الإنجليزية
   ✅ تمت إضافة الترجمة: الترجمة الدولية الصحيحة
      المترجم: الترجمة الدولية الصحيحة
      رقم الاعتماد: AZHAR-EN-001-2020
   ✅ تم استيراد 6236 آية

🎉 اكتمل الاستيراد!
   📚 عدد الترجمات: 1
   📖 عدد الآيات المترجمة: 6236
```

---

#### **3. التحقق من الاستيراد**

```bash
# التحقق من الترجمات
psql -U postgres -d haderos_db -c "SELECT * FROM azhar_approved_translations;"

# التحقق من الآيات المترجمة
psql -U postgres -d haderos_db -c "SELECT COUNT(*) FROM verse_translations;"

# التحقق من اللغات المدعومة
psql -U postgres -d haderos_db -c "SELECT * FROM supported_languages;"
```

---

## 🔒 الأمان والتحقق

### **التحقق من الاعتماد:**

كل ترجمة يجب أن تحتوي على:

1. ✅ **رقم اعتماد فريد** من الأزهر الشريف
2. ✅ **تاريخ الاعتماد** الرسمي
3. ✅ **اسم المعتمد** من الأزهر
4. ✅ **رابط المستند** (اختياري لكن موصى به)

---

### **التحقق البرمجي:**

```typescript
// التحقق من صحة الترجمة قبل الاستخدام
const verification = await translationEngine.verifyTranslation(approvalNumber);

if (!verification.isValid) {
  throw new Error('ترجمة غير معتمدة!');
}

// استخدام الترجمة
const verse = await translationEngine.getVerseWithTranslation(verseId, {
  language: 'en',
  translationId: verification.translation.id
});
```

---

## 📊 الإحصائيات والتقارير

### **إحصائيات الاستخدام:**

```typescript
const stats = await translationEngine.getTranslationStatistics('en');

// النتيجة:
{
  totalTranslations: 3,
  totalLanguages: 15,
  totalVerses: 6236,
  translatedVerses: 6236,
  completionPercentage: 100,
  topTranslations: [
    {
      translationName: "Sahih International",
      timesUsed: 15420,
      averageRating: 4.8
    }
  ]
}
```

---

### **تقرير الترجمات:**

```sql
-- الترجمات الأكثر استخداماً
SELECT 
  t.translation_name_ar,
  t.translator_name_ar,
  t.times_used,
  t.average_rating
FROM azhar_approved_translations t
WHERE t.is_active = TRUE
ORDER BY t.times_used DESC
LIMIT 10;

-- نسبة الاكتمال لكل لغة
SELECT 
  l.name_ar,
  l.completion_percentage,
  l.is_complete
FROM supported_languages l
WHERE l.is_active = TRUE
ORDER BY l.completion_percentage DESC;
```

---

## 🚀 أفضل الممارسات

### **1. عرض الآيات:**

```typescript
// ✅ صحيح: النص العربي دائماً مرئي
<QuranicVerseWithTranslation
  verseId={1}
  language="en"
  showArabicText={true} // دائماً true
/>

// ❌ خطأ: إخفاء النص العربي
<QuranicVerseWithTranslation
  verseId={1}
  language="en"
  showArabicText={false} // غير مسموح!
/>
```

---

### **2. اختيار الترجمة:**

```typescript
// ✅ صحيح: استخدام الترجمة الافتراضية
const verse = await translationEngine.getVerseWithTranslation(verseId, {
  language: 'en',
  // translationId غير محدد = الترجمة الافتراضية
});

// ✅ صحيح: استخدام ترجمة محددة
const verse = await translationEngine.getVerseWithTranslation(verseId, {
  language: 'en',
  translationId: 2 // ترجمة محددة
});
```

---

### **3. التحقق من الاعتماد:**

```typescript
// ✅ صحيح: التحقق قبل الاستخدام
const verification = await translationEngine.verifyTranslation(approvalNumber);
if (verification.isValid) {
  // استخدام الترجمة
}

// ✅ صحيح: عرض بيانات الاعتماد للمستخدم
<QuranicVerseWithTranslation
  verseId={1}
  language="en"
  showTranslationInfo={true} // عرض معلومات الاعتماد
/>
```

---

## 🆘 حل المشاكل الشائعة

### **المشكلة 1: الترجمة لا تظهر**

**الأسباب المحتملة:**
- اللغة غير مدعومة
- لا توجد ترجمة معتمدة لهذه اللغة
- الترجمة غير نشطة

**الحل:**
```typescript
// التحقق من دعم اللغة
const isSupported = await isLanguageSupported('en');
if (!isSupported) {
  console.log('اللغة غير مدعومة');
}

// التحقق من الترجمات المتاحة
const translations = await translationEngine.getAvailableTranslations('en');
if (translations.length === 0) {
  console.log('لا توجد ترجمات معتمدة لهذه اللغة');
}
```

---

### **المشكلة 2: خطأ في الاستيراد**

**الأسباب المحتملة:**
- تنسيق ملف JSON خاطئ
- رقم اعتماد مكرر
- آية غير موجودة في قاعدة البيانات

**الحل:**
```bash
# التحقق من صحة JSON
cat sahih-international.json | jq .

# التحقق من الآيات
psql -U postgres -d haderos_db -c "SELECT COUNT(*) FROM quranic_verses;"

# إعادة الاستيراد مع تفاصيل الأخطاء
pnpm tsx scripts/import-azhar-translations.ts --verbose
```

---

### **المشكلة 3: بطء في التحميل**

**الأسباب المحتملة:**
- عدم وجود indexes
- استعلامات غير محسّنة

**الحل:**
```sql
-- إنشاء indexes إضافية
CREATE INDEX IF NOT EXISTS verse_translations_verse_id_idx 
  ON verse_translations(verse_id);

CREATE INDEX IF NOT EXISTS verse_translations_translation_id_idx 
  ON verse_translations(translation_id);

-- تحليل الأداء
EXPLAIN ANALYZE 
SELECT * FROM verse_translations 
WHERE verse_id = 1 AND translation_id = 1;
```

---

## 📞 الدعم

للمساعدة في نظام الترجمات:
- 📧 البريد: translations@haderos.ai
- 💬 الدردشة: داخل المنصة
- 📚 الوثائق: docs.haderos.ai/kaia/translations

---

## ✅ قائمة التحقق

### **قبل إضافة ترجمة جديدة:**

- [ ] الحصول على الاعتماد الرسمي من الأزهر
- [ ] تحضير ملف JSON بالتنسيق الصحيح
- [ ] التحقق من رقم الاعتماد الفريد
- [ ] مراجعة جميع الآيات المترجمة
- [ ] اختبار الاستيراد على بيئة التطوير

### **بعد إضافة ترجمة جديدة:**

- [ ] التحقق من نجاح الاستيراد
- [ ] اختبار عرض الآيات
- [ ] التحقق من بيانات الاعتماد
- [ ] تحديث الوثائق
- [ ] إعلام المستخدمين

---

**🕌 "القرآن بالعربية، والفهم بجميع اللغات"**

*KAIA Translation System - Powered by Al-Azhar Approved Translations*

---

**تاريخ التحديث:** 29 ديسمبر 2024  
**الإصدار:** 1.0.0

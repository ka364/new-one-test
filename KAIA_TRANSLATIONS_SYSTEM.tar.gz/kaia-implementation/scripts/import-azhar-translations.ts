/**
 * Import Al-Azhar Approved Translations
 * استيراد الترجمات المعتمدة من الأزهر
 * 
 * هذا Script يستورد الترجمات المعتمدة رسمياً من الأزهر الشريف
 */

import { db } from '../server/db';
import {
  azharApprovedTranslations,
  verseTranslations,
  supportedLanguages,
  type NewAzharApprovedTranslation,
  type NewVerseTranslation,
  type NewSupportedLanguage
} from '../database/schema-kaia-translations';
import { quranicVerses } from '../database/schema-kaia';
import fs from 'fs/promises';
import path from 'path';

// ===== Types =====

interface TranslationFile {
  metadata: {
    translationName: string;
    translationNameAr: string;
    language: string;
    languageNameAr: string;
    translatorName: string;
    translatorNameAr: string;
    translatorBio?: string;
    translatorBioAr?: string;
    azharApprovalNumber: string;
    azharApprovalDate: string;
    azharApprovalDocument?: string;
    approvedBy: string;
    approvedByTitle?: string;
    publisher?: string;
    publishYear?: number;
    isbn?: string;
    isDefault?: boolean;
  };
  verses: Array<{
    verseKey: string; // "1:1", "2:255", etc.
    translatedText: string;
    translationNotes?: string;
  }>;
}

// ===== Main Function =====

async function importAzharTranslations() {
  console.log('🕌 بدء استيراد الترجمات المعتمدة من الأزهر الشريف...\n');
  
  try {
    // 1. قراءة ملفات الترجمات
    const translationsDir = path.join(__dirname, '../data/azhar-translations');
    const files = await fs.readdir(translationsDir);
    const jsonFiles = files.filter(f => f.endsWith('.json'));
    
    console.log(`📁 تم العثور على ${jsonFiles.length} ملف ترجمة\n`);
    
    let totalTranslations = 0;
    let totalVerses = 0;
    
    // 2. استيراد كل ترجمة
    for (const file of jsonFiles) {
      console.log(`📖 استيراد: ${file}...`);
      
      const filePath = path.join(translationsDir, file);
      const content = await fs.readFile(filePath, 'utf-8');
      const translation: TranslationFile = JSON.parse(content);
      
      // 3. إضافة اللغة إلى قائمة اللغات المدعومة (إن لم تكن موجودة)
      await addSupportedLanguage(translation.metadata);
      
      // 4. إضافة الترجمة
      const translationId = await addTranslation(translation.metadata);
      
      // 5. إضافة الآيات المترجمة
      const versesImported = await addVerseTranslations(
        translationId,
        translation.verses
      );
      
      totalTranslations++;
      totalVerses += versesImported;
      
      console.log(`   ✅ تم استيراد ${versesImported} آية\n`);
    }
    
    console.log(`\n🎉 اكتمل الاستيراد!`);
    console.log(`   📚 عدد الترجمات: ${totalTranslations}`);
    console.log(`   📖 عدد الآيات المترجمة: ${totalVerses}`);
    
  } catch (error) {
    console.error('\n❌ خطأ في الاستيراد:', error);
    throw error;
  }
}

// ===== Helper Functions =====

/**
 * إضافة لغة إلى قائمة اللغات المدعومة
 */
async function addSupportedLanguage(metadata: TranslationFile['metadata']): Promise<void> {
  const existing = await db.query.supportedLanguages.findFirst({
    where: (langs, { eq }) => eq(langs.code, metadata.language)
  });
  
  if (existing) {
    console.log(`   ℹ️  اللغة ${metadata.languageNameAr} موجودة مسبقاً`);
    return;
  }
  
  const languageData: NewSupportedLanguage = {
    code: metadata.language,
    nameEn: getEnglishLanguageName(metadata.language),
    nameAr: metadata.languageNameAr,
    nativeName: getNativeLanguageName(metadata.language),
    direction: metadata.language === 'ar' ? 'rtl' : 'ltr',
    isActive: true,
    isComplete: false,
    completionPercentage: 0
  };
  
  await db.insert(supportedLanguages).values(languageData);
  console.log(`   ✅ تمت إضافة اللغة: ${metadata.languageNameAr}`);
}

/**
 * إضافة ترجمة معتمدة
 */
async function addTranslation(metadata: TranslationFile['metadata']): Promise<number> {
  // التحقق من عدم وجود الترجمة مسبقاً
  const existing = await db.query.azharApprovedTranslations.findFirst({
    where: (trans, { eq }) => eq(trans.azharApprovalNumber, metadata.azharApprovalNumber)
  });
  
  if (existing) {
    console.log(`   ⚠️  الترجمة موجودة مسبقاً (رقم الاعتماد: ${metadata.azharApprovalNumber})`);
    return existing.id;
  }
  
  const translationData: NewAzharApprovedTranslation = {
    translationName: metadata.translationName,
    translationNameAr: metadata.translationNameAr,
    language: metadata.language,
    languageNameAr: metadata.languageNameAr,
    translatorName: metadata.translatorName,
    translatorNameAr: metadata.translatorNameAr,
    translatorBio: metadata.translatorBio,
    translatorBioAr: metadata.translatorBioAr,
    azharApprovalNumber: metadata.azharApprovalNumber,
    azharApprovalDate: new Date(metadata.azharApprovalDate),
    azharApprovalDocument: metadata.azharApprovalDocument,
    approvedBy: metadata.approvedBy,
    approvedByTitle: metadata.approvedByTitle,
    publisher: metadata.publisher,
    publishYear: metadata.publishYear,
    isbn: metadata.isbn,
    isActive: true,
    isDefault: metadata.isDefault || false
  };
  
  const result = await db.insert(azharApprovedTranslations)
    .values(translationData)
    .returning({ id: azharApprovedTranslations.id });
  
  console.log(`   ✅ تمت إضافة الترجمة: ${metadata.translationNameAr}`);
  console.log(`      المترجم: ${metadata.translatorNameAr}`);
  console.log(`      رقم الاعتماد: ${metadata.azharApprovalNumber}`);
  
  return result[0].id;
}

/**
 * إضافة الآيات المترجمة
 */
async function addVerseTranslations(
  translationId: number,
  verses: TranslationFile['verses']
): Promise<number> {
  let imported = 0;
  
  for (const verse of verses) {
    // الحصول على ID الآية من verseKey
    const quranicVerse = await db.query.quranicVerses.findFirst({
      where: (verses, { eq }) => eq(verses.verseKey, verse.verseKey)
    });
    
    if (!quranicVerse) {
      console.log(`   ⚠️  الآية ${verse.verseKey} غير موجودة في قاعدة البيانات`);
      continue;
    }
    
    // التحقق من عدم وجود الترجمة مسبقاً
    const existing = await db.query.verseTranslations.findFirst({
      where: (trans, { and, eq }) => and(
        eq(trans.verseId, quranicVerse.id),
        eq(trans.translationId, translationId)
      )
    });
    
    if (existing) {
      continue;
    }
    
    // إضافة الترجمة
    const verseTranslationData: NewVerseTranslation = {
      verseId: quranicVerse.id,
      translationId,
      translatedText: verse.translatedText,
      translationNotes: verse.translationNotes,
      isVerified: true
    };
    
    await db.insert(verseTranslations).values(verseTranslationData);
    imported++;
  }
  
  // تحديث نسبة الاكتمال للغة
  await updateLanguageCompletion(translationId);
  
  return imported;
}

/**
 * تحديث نسبة اكتمال الترجمة للغة
 */
async function updateLanguageCompletion(translationId: number): Promise<void> {
  const translation = await db.query.azharApprovedTranslations.findFirst({
    where: (trans, { eq }) => eq(trans.id, translationId)
  });
  
  if (!translation) return;
  
  // عدد الآيات المترجمة
  const translatedCount = await db.query.verseTranslations.count({
    where: (trans, { eq }) => eq(trans.translationId, translationId)
  });
  
  // عدد الآيات الكلي
  const totalCount = 6236;
  
  // نسبة الاكتمال
  const completionPercentage = Math.floor((translatedCount / totalCount) * 100);
  
  // تحديث اللغة
  await db.update(supportedLanguages)
    .set({
      completionPercentage,
      isComplete: completionPercentage === 100
    })
    .where((langs, { eq }) => eq(langs.code, translation.language));
}

// ===== Language Helpers =====

function getEnglishLanguageName(code: string): string {
  const names: Record<string, string> = {
    'en': 'English',
    'fr': 'French',
    'de': 'German',
    'es': 'Spanish',
    'tr': 'Turkish',
    'ur': 'Urdu',
    'fa': 'Persian',
    'id': 'Indonesian',
    'ms': 'Malay',
    'bn': 'Bengali',
    'ru': 'Russian',
    'zh': 'Chinese'
  };
  
  return names[code] || code.toUpperCase();
}

function getNativeLanguageName(code: string): string {
  const names: Record<string, string> = {
    'en': 'English',
    'fr': 'Français',
    'de': 'Deutsch',
    'es': 'Español',
    'tr': 'Türkçe',
    'ur': 'اردو',
    'fa': 'فارسی',
    'id': 'Bahasa Indonesia',
    'ms': 'Bahasa Melayu',
    'bn': 'বাংলা',
    'ru': 'Русский',
    'zh': '中文'
  };
  
  return names[code] || code.toUpperCase();
}

// ===== Example Translation File Format =====

/**
 * مثال على تنسيق ملف الترجمة:
 * 
 * {
 *   "metadata": {
 *     "translationName": "Sahih International",
 *     "translationNameAr": "الترجمة الدولية الصحيحة",
 *     "language": "en",
 *     "languageNameAr": "الإنجليزية",
 *     "translatorName": "Saheeh International",
 *     "translatorNameAr": "الترجمة الدولية الصحيحة",
 *     "azharApprovalNumber": "AZHAR-EN-001-2020",
 *     "azharApprovalDate": "2020-01-15",
 *     "approvedBy": "لجنة الترجمة بالأزهر الشريف",
 *     "isDefault": true
 *   },
 *   "verses": [
 *     {
 *       "verseKey": "1:1",
 *       "translatedText": "In the name of Allah, the Entirely Merciful, the Especially Merciful."
 *     },
 *     {
 *       "verseKey": "1:2",
 *       "translatedText": "[All] praise is [due] to Allah, Lord of the worlds -"
 *     }
 *   ]
 * }
 */

// ===== Run =====

importAzharTranslations()
  .then(() => {
    console.log('\n✅ تم الاستيراد بنجاح!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ فشل الاستيراد:', error);
    process.exit(1);
  });

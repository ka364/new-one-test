/**
 * KAIA Translations Schema - إضافة دعم الترجمات المعتمدة من الأزهر
 * 
 * المبدأ الأساسي:
 * - النص العربي الأصلي لا يُترجم أبداً
 * - الترجمات المعتمدة من الأزهر فقط
 * - التوجيه الأخلاقي والتطبيق العملي قابل للترجمة
 */

import { pgTable, text, integer, varchar, timestamp, boolean, index, jsonb } from 'drizzle-orm/pg-core';
import { quranicVerses } from './schema-kaia';

// ===== جدول الترجمات المعتمدة =====

/**
 * جدول الترجمات المعتمدة من الأزهر
 * يحتوي على ترجمات رسمية معتمدة فقط
 */
export const azharApprovedTranslations = pgTable('azhar_approved_translations', {
  id: integer().primaryKey().generatedByDefaultAsIdentity(),
  
  // معلومات الترجمة
  translationName: varchar('translation_name', { length: 200 }).notNull(),
  translationNameAr: varchar('translation_name_ar', { length: 200 }).notNull(),
  language: varchar('language', { length: 10 }).notNull(), // en, fr, de, es, etc.
  languageNameAr: varchar('language_name_ar', { length: 50 }).notNull(),
  
  // المترجم
  translatorName: varchar('translator_name', { length: 200 }).notNull(),
  translatorNameAr: varchar('translator_name_ar', { length: 200 }).notNull(),
  translatorBio: text('translator_bio'),
  translatorBioAr: text('translator_bio_ar'),
  
  // الاعتماد من الأزهر
  azharApprovalNumber: varchar('azhar_approval_number', { length: 100 }).notNull().unique(),
  azharApprovalDate: timestamp('azhar_approval_date').notNull(),
  azharApprovalDocument: text('azhar_approval_document'), // رابط المستند
  approvedBy: varchar('approved_by', { length: 200 }).notNull(), // اسم المعتمد من الأزهر
  approvedByTitle: varchar('approved_by_title', { length: 200 }), // منصبه
  
  // معلومات النشر
  publisher: varchar('publisher', { length: 200 }),
  publishYear: integer('publish_year'),
  isbn: varchar('isbn', { length: 50 }),
  
  // الحالة
  isActive: boolean('is_active').default(true),
  isDefault: boolean('is_default').default(false), // الترجمة الافتراضية لهذه اللغة
  
  // الإحصائيات
  timesUsed: integer('times_used').default(0),
  averageRating: integer('average_rating'), // 1-5
  
  // البيانات الوصفية
  notes: text('notes'),
  notesAr: text('notes_ar'),
  
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
}, (table) => ({
  languageIdx: index('translations_language_idx').on(table.language),
  approvalNumberIdx: index('translations_approval_number_idx').on(table.azharApprovalNumber),
  isActiveIdx: index('translations_is_active_idx').on(table.isActive)
}));

/**
 * جدول ترجمات الآيات
 * يربط كل آية بترجماتها المعتمدة
 */
export const verseTranslations = pgTable('verse_translations', {
  id: integer().primaryKey().generatedByDefaultAsIdentity(),
  
  // الآية
  verseId: integer('verse_id').references(() => quranicVerses.id).notNull(),
  
  // الترجمة
  translationId: integer('translation_id').references(() => azharApprovedTranslations.id).notNull(),
  
  // النص المترجم
  translatedText: text('translated_text').notNull(),
  
  // ملاحظات على هذه الآية بالذات
  translationNotes: text('translation_notes'),
  
  // المراجعة
  reviewedBy: varchar('reviewed_by', { length: 200 }), // من راجع هذه الترجمة
  reviewedAt: timestamp('reviewed_at'),
  reviewNotes: text('review_notes'),
  
  // الحالة
  isVerified: boolean('is_verified').default(true),
  
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
}, (table) => ({
  verseIdIdx: index('verse_translations_verse_id_idx').on(table.verseId),
  translationIdIdx: index('verse_translations_translation_id_idx').on(table.translationId),
  verseTranslationIdx: index('verse_translation_unique_idx').on(table.verseId, table.translationId)
}));

/**
 * جدول ترجمات المبادئ الأخلاقية
 * ترجمة التوجيه الأخلاقي (ليس القرآن)
 */
export const ethicalPrincipleTranslations = pgTable('ethical_principle_translations', {
  id: integer().primaryKey().generatedByDefaultAsIdentity(),
  
  // الآية
  verseId: integer('verse_id').references(() => quranicVerses.id).notNull(),
  
  // اللغة
  language: varchar('language', { length: 10 }).notNull(),
  
  // المبدأ الأخلاقي المترجم (هذا ليس قرآن، يمكن ترجمته بحرية)
  ethicalPrinciple: text('ethical_principle').notNull(),
  
  // التطبيقات الإدارية المترجمة
  managementApplications: jsonb('management_applications').$type<Record<string, string>>().default({}),
  
  // الكلمات المفتاحية المترجمة
  keywords: jsonb('keywords').$type<string[]>().default([]),
  
  // المترجم
  translatedBy: varchar('translated_by', { length: 200 }),
  translatedAt: timestamp('translated_at').defaultNow(),
  
  // المراجعة
  reviewedBy: varchar('reviewed_by', { length: 200 }),
  reviewedAt: timestamp('reviewed_at'),
  
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
}, (table) => ({
  verseIdIdx: index('ethical_translations_verse_id_idx').on(table.verseId),
  languageIdx: index('ethical_translations_language_idx').on(table.language),
  verseLanguageIdx: index('ethical_verse_language_idx').on(table.verseId, table.language)
}));

/**
 * جدول اللغات المدعومة
 * قائمة اللغات التي نوفر لها ترجمات معتمدة
 */
export const supportedLanguages = pgTable('supported_languages', {
  id: integer().primaryKey().generatedByDefaultAsIdentity(),
  
  // اللغة
  code: varchar('code', { length: 10 }).notNull().unique(), // en, fr, de, es, etc.
  nameEn: varchar('name_en', { length: 100 }).notNull(),
  nameAr: varchar('name_ar', { length: 100 }).notNull(),
  nativeName: varchar('native_name', { length: 100 }).notNull(),
  
  // الاتجاه
  direction: varchar('direction', { length: 3 }).notNull().default('ltr'), // ltr or rtl
  
  // الترجمة الافتراضية
  defaultTranslationId: integer('default_translation_id').references(() => azharApprovedTranslations.id),
  
  // الحالة
  isActive: boolean('is_active').default(true),
  isComplete: boolean('is_complete').default(false), // هل جميع الآيات مترجمة؟
  completionPercentage: integer('completion_percentage').default(0),
  
  // الإحصائيات
  totalUsers: integer('total_users').default(0),
  totalInteractions: integer('total_interactions').default(0),
  
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
}, (table) => ({
  codeIdx: index('supported_languages_code_idx').on(table.code),
  isActiveIdx: index('supported_languages_is_active_idx').on(table.isActive)
}));

/**
 * جدول تفضيلات المستخدم للترجمة
 * حفظ اختيار المستخدم للترجمة المفضلة
 */
export const userTranslationPreferences = pgTable('user_translation_preferences', {
  id: integer().primaryKey().generatedByDefaultAsIdentity(),
  
  userId: integer('user_id').notNull(), // references users.id
  
  // اللغة المفضلة
  preferredLanguage: varchar('preferred_language', { length: 10 }).notNull(),
  
  // الترجمة المفضلة
  preferredTranslationId: integer('preferred_translation_id').references(() => azharApprovedTranslations.id),
  
  // الإعدادات
  showArabicText: boolean('show_arabic_text').default(true), // دائماً true
  showTranslation: boolean('show_translation').default(true),
  showTransliteration: boolean('show_transliteration').default(false),
  
  // حجم الخط
  arabicFontSize: integer('arabic_font_size').default(18),
  translationFontSize: integer('translation_font_size').default(14),
  
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
}, (table) => ({
  userIdIdx: index('user_translation_prefs_user_id_idx').on(table.userId)
}));

/**
 * جدول سجل استخدام الترجمات
 * تتبع استخدام الترجمات المختلفة
 */
export const translationUsageLog = pgTable('translation_usage_log', {
  id: integer().primaryKey().generatedByDefaultAsIdentity(),
  
  userId: integer('user_id'),
  verseId: integer('verse_id').references(() => quranicVerses.id),
  translationId: integer('translation_id').references(() => azharApprovedTranslations.id),
  language: varchar('language', { length: 10 }).notNull(),
  
  // السياق
  context: varchar('context', { length: 50 }),
  
  // التفاعل
  viewDuration: integer('view_duration'), // بالثواني
  wasHelpful: boolean('was_helpful'),
  feedback: text('feedback'),
  
  createdAt: timestamp('created_at').defaultNow()
}, (table) => ({
  translationIdIdx: index('translation_usage_translation_id_idx').on(table.translationId),
  languageIdx: index('translation_usage_language_idx').on(table.language),
  createdAtIdx: index('translation_usage_created_at_idx').on(table.createdAt)
}));

/**
 * جدول طلبات الترجمة الجديدة
 * المستخدمون يمكنهم طلب ترجمات للغات جديدة
 */
export const translationRequests = pgTable('translation_requests', {
  id: integer().primaryKey().generatedByDefaultAsIdentity(),
  
  // اللغة المطلوبة
  requestedLanguage: varchar('requested_language', { length: 10 }).notNull(),
  requestedLanguageName: varchar('requested_language_name', { length: 100 }).notNull(),
  
  // مقدم الطلب
  requestedBy: integer('requested_by'), // user_id
  requestedByEmail: varchar('requested_by_email', { length: 255 }),
  
  // التفاصيل
  reason: text('reason'),
  estimatedUsers: integer('estimated_users'), // عدد المستخدمين المتوقعين
  
  // الأولوية
  priority: integer('priority').default(5), // 1-10
  votes: integer('votes').default(0), // تصويت المستخدمين
  
  // الحالة
  status: varchar('status', { length: 20 }).default('pending'), // pending, approved, in_progress, completed, rejected
  statusNotes: text('status_notes'),
  
  // التقدم
  translationProgress: integer('translation_progress').default(0), // 0-100
  assignedTranslationId: integer('assigned_translation_id').references(() => azharApprovedTranslations.id),
  
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
}, (table) => ({
  requestedLanguageIdx: index('translation_requests_language_idx').on(table.requestedLanguage),
  statusIdx: index('translation_requests_status_idx').on(table.status)
}));

// ===== Types للتصدير =====

export type AzharApprovedTranslation = typeof azharApprovedTranslations.$inferSelect;
export type NewAzharApprovedTranslation = typeof azharApprovedTranslations.$inferInsert;

export type VerseTranslation = typeof verseTranslations.$inferSelect;
export type NewVerseTranslation = typeof verseTranslations.$inferInsert;

export type EthicalPrincipleTranslation = typeof ethicalPrincipleTranslations.$inferSelect;
export type NewEthicalPrincipleTranslation = typeof ethicalPrincipleTranslations.$inferInsert;

export type SupportedLanguage = typeof supportedLanguages.$inferSelect;
export type NewSupportedLanguage = typeof supportedLanguages.$inferInsert;

export type UserTranslationPreference = typeof userTranslationPreferences.$inferSelect;
export type NewUserTranslationPreference = typeof userTranslationPreferences.$inferInsert;

export type TranslationUsageLog = typeof translationUsageLog.$inferSelect;
export type NewTranslationUsageLog = typeof translationUsageLog.$inferInsert;

export type TranslationRequest = typeof translationRequests.$inferSelect;
export type NewTranslationRequest = typeof translationRequests.$inferInsert;

// ===== Helper Functions =====

/**
 * الحصول على الترجمة المعتمدة لآية معينة
 */
export interface GetVerseTranslationParams {
  verseId: number;
  language: string;
  translationId?: number; // اختياري: ترجمة محددة
}

/**
 * الحصول على جميع الترجمات المتاحة للغة معينة
 */
export interface GetAvailableTranslationsParams {
  language: string;
  activeOnly?: boolean;
}

/**
 * تسجيل استخدام ترجمة
 */
export interface LogTranslationUsageParams {
  userId?: number;
  verseId: number;
  translationId: number;
  language: string;
  context?: string;
  viewDuration?: number;
}

from sqlalchemy.orm import Session
from app.models import Order, Inventory, AuditLog, OrderStatus
from app.schemas import OrderCreate, InventoryCreate
from datetime import datetime

class OrderService:
    @staticmethod
    def create_order(db: Session, order_data: OrderCreate) -> Order:
        """Create a new order"""
        order = Order(
            order_id=order_data.order_id,
            customer_id=order_data.customer_id,
            product_id=order_data.product_id,
            quantity=order_data.quantity,
            status=OrderStatus.RECEIVED
        )
        db.add(order)
        db.commit()
        db.refresh(order)
        
        # Log the action
        AuditLog.log_action(
            db=db,
            action="ORDER_CREATED",
            actor="system",
            order_id=order.order_id,
            details=f"Order created: {order.order_id}"
        )
        
        return order

    @staticmethod
    def validate_order(db: Session, order_id: str) -> tuple[bool, str]:
        """
        Validate order against inventory
        Returns: (is_valid, reason)
        """
        order = db.query(Order).filter(Order.order_id == order_id).first()
        if not order:
            return False, "Order not found"
        
        inventory = db.query(Inventory).filter(
            Inventory.product_id == order.product_id
        ).first()
        
        if not inventory:
            return False, "Product not found in inventory"
        
        available = inventory.quantity_available - inventory.quantity_reserved
        if available < order.quantity:
            return False, f"Insufficient inventory. Available: {available}, Requested: {order.quantity}"
        
        return True, ""

    @staticmethod
    def confirm_order(db: Session, order_id: str) -> Order:
        """
        Confirm order (apply ethical rule: "Don't sell what you don't have")
        """
        order = db.query(Order).filter(Order.order_id == order_id).first()
        if not order:
            raise ValueError("Order not found")
        
        # Validate inventory
        is_valid, reason = OrderService.validate_order(db, order_id)
        
        if not is_valid:
            order.status = OrderStatus.REJECTED
            order.rejection_reason = reason
            db.commit()
            
            AuditLog.log_action(
                db=db,
                action="ORDER_REJECTED",
                actor="system",
                order_id=order_id,
                reason=reason
            )
            return order
        
        # Confirm order and reserve inventory
        order.status = OrderStatus.CONFIRMED
        inventory = db.query(Inventory).filter(
            Inventory.product_id == order.product_id
        ).first()
        inventory.quantity_reserved += order.quantity
        
        db.commit()
        db.refresh(order)
        
        AuditLog.log_action(
            db=db,
            action="ORDER_CONFIRMED",
            actor="system",
            order_id=order_id,
            details=f"Order confirmed and inventory reserved"
        )
        
        return order

    @staticmethod
    def get_order(db: Session, order_id: str) -> Order:
        """Get order by ID"""
        return db.query(Order).filter(Order.order_id == order_id).first()

    @staticmethod
    def get_all_orders(db: Session, skip: int = 0, limit: int = 100):
        """Get all orders with pagination"""
        return db.query(Order).offset(skip).limit(limit).all()


class InventoryService:
    @staticmethod
    def create_inventory(db: Session, inventory_data: InventoryCreate) -> Inventory:
        """Create inventory entry"""
        inventory = Inventory(
            product_id=inventory_data.product_id,
            quantity_available=inventory_data.quantity_available
        )
        db.add(inventory)
        db.commit()
        db.refresh(inventory)
        
        AuditLog.log_action(
            db=db,
            action="INVENTORY_CREATED",
            actor="system",
            details=f"Inventory created for {inventory.product_id}: {inventory.quantity_available} units"
        )
        
        return inventory

    @staticmethod
    def update_inventory(db: Session, product_id: str, quantity: int) -> Inventory:
        """Update inventory quantity"""
        inventory = db.query(Inventory).filter(
            Inventory.product_id == product_id
        ).first()
        
        if not inventory:
            raise ValueError("Product not found in inventory")
        
        old_quantity = inventory.quantity_available
        inventory.quantity_available = quantity
        db.commit()
        db.refresh(inventory)
        
        AuditLog.log_action(
            db=db,
            action="INVENTORY_UPDATED",
            actor="system",
            details=f"Inventory updated for {product_id}: {old_quantity} -> {quantity}"
        )
        
        return inventory

    @staticmethod
    def get_inventory(db: Session, product_id: str) -> Inventory:
        """Get inventory by product ID"""
        return db.query(Inventory).filter(
            Inventory.product_id == product_id
        ).first()


class AuditLogService:
    @staticmethod
    def log_action(db: Session, action: str, actor: str, order_id: str = None, 
                   details: str = None, reason: str = None) -> AuditLog:
        """Log an action to audit trail"""
        log = AuditLog(
            action=action,
            actor=actor,
            order_id=order_id,
            details=details,
            reason=reason,
            timestamp=datetime.utcnow()
        )
        db.add(log)
        db.commit()
        db.refresh(log)
        return log

    @staticmethod
    def get_logs(db: Session, order_id: str = None, skip: int = 0, limit: int = 100):
        """Get audit logs with optional filtering"""
        query = db.query(AuditLog)
        if order_id:
            query = query.filter(AuditLog.order_id == order_id)
        return query.offset(skip).limit(limit).all()


# Add static method to AuditLog model
AuditLog.log_action = staticmethod(AuditLogService.log_action)

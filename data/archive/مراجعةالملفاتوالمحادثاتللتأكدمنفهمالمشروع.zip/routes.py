from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas import OrderCreate, OrderUpdate, OrderResponse, InventoryCreate, InventoryResponse, AuditLogResponse
from app.services import OrderService, InventoryService, AuditLogService

router = APIRouter()

# ==================== ORDER ENDPOINTS ====================

@router.post("/orders", response_model=OrderResponse)
def create_order(order: OrderCreate, db: Session = Depends(get_db)):
    """Create a new order"""
    try:
        return OrderService.create_order(db, order)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/orders/{order_id}", response_model=OrderResponse)
def get_order(order_id: str, db: Session = Depends(get_db)):
    """Get order by ID"""
    order = OrderService.get_order(db, order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order

@router.get("/orders", response_model=list[OrderResponse])
def list_orders(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """List all orders"""
    return OrderService.get_all_orders(db, skip, limit)

@router.post("/orders/{order_id}/validate")
def validate_order(order_id: str, db: Session = Depends(get_db)):
    """Validate order against inventory"""
    is_valid, reason = OrderService.validate_order(db, order_id)
    return {
        "order_id": order_id,
        "is_valid": is_valid,
        "reason": reason if not is_valid else "Order is valid"
    }

@router.post("/orders/{order_id}/confirm", response_model=OrderResponse)
def confirm_order(order_id: str, db: Session = Depends(get_db)):
    """
    Confirm order (applies ethical rule: "Don't sell what you don't have")
    """
    try:
        return OrderService.confirm_order(db, order_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ==================== INVENTORY ENDPOINTS ====================

@router.post("/inventory", response_model=InventoryResponse)
def create_inventory(inventory: InventoryCreate, db: Session = Depends(get_db)):
    """Create inventory entry"""
    try:
        return InventoryService.create_inventory(db, inventory)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/inventory/{product_id}", response_model=InventoryResponse)
def get_inventory(product_id: str, db: Session = Depends(get_db)):
    """Get inventory by product ID"""
    inventory = InventoryService.get_inventory(db, product_id)
    if not inventory:
        raise HTTPException(status_code=404, detail="Product not found in inventory")
    return inventory

@router.put("/inventory/{product_id}", response_model=InventoryResponse)
def update_inventory(product_id: str, quantity: int, db: Session = Depends(get_db)):
    """Update inventory quantity"""
    try:
        return InventoryService.update_inventory(db, product_id, quantity)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ==================== AUDIT LOG ENDPOINTS ====================

@router.get("/audit-logs", response_model=list[AuditLogResponse])
def get_audit_logs(order_id: str = None, skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """Get audit logs"""
    return AuditLogService.get_logs(db, order_id, skip, limit)

# ==================== HEALTH CHECK ====================

@router.get("/health")
def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "HaderOS NOW SHOES Pilot"}

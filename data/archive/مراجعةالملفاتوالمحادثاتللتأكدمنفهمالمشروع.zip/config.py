from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # Database
    database_url: str = "postgresql://haderos_user:haderos_password_dev@postgres:5432/haderos_nowshoes"
    
    # Application
    app_name: str = "HaderOS NOW SHOES Pilot"
    app_version: str = "0.1.0"
    debug: bool = True
    
    # Environment
    environment: str = "development"
    
    class Config:
        env_file = ".env"
        case_sensitive = False

settings = Settings()
